#ifndef SWITCH
#define SWITCH

#include <GL/glut.h>
#include <iostream>

#endif SWITCH